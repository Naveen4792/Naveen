﻿
namespace HistoricalDataApp
{
    partial class frmHistoricalData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHistoricalData));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.btnstart = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chkdeviceweather = new System.Windows.Forms.CheckBox();
            this.chkdevicestorage = new System.Windows.Forms.CheckBox();
            this.chkdevicecurrentwifi = new System.Windows.Forms.CheckBox();
            this.chkdevicenameandos = new System.Windows.Forms.CheckBox();
            this.chkdevicebatterylevel = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dvhistory = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvhistory)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(-2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(793, 81);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.btnStop);
            this.tabPage1.Controls.Add(this.btnClose);
            this.tabPage1.Controls.Add(this.btnreset);
            this.tabPage1.Controls.Add(this.btnstart);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(785, 55);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Process";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("Microsoft Tai Le", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.ForeColor = System.Drawing.Color.Maroon;
            this.btnStop.Image = ((System.Drawing.Image)(resources.GetObject("btnStop.Image")));
            this.btnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStop.Location = new System.Drawing.Point(89, 6);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 43);
            this.btnStop.TabIndex = 3;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnClose
            // 
            this.btnClose.ForeColor = System.Drawing.Color.Maroon;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(251, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 43);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnreset
            // 
            this.btnreset.ForeColor = System.Drawing.Color.Maroon;
            this.btnreset.Image = ((System.Drawing.Image)(resources.GetObject("btnreset.Image")));
            this.btnreset.Location = new System.Drawing.Point(170, 6);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 43);
            this.btnreset.TabIndex = 1;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnstart
            // 
            this.btnstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstart.ForeColor = System.Drawing.Color.Maroon;
            this.btnstart.Image = ((System.Drawing.Image)(resources.GetObject("btnstart.Image")));
            this.btnstart.Location = new System.Drawing.Point(6, 6);
            this.btnstart.Name = "btnstart";
            this.btnstart.Size = new System.Drawing.Size(77, 43);
            this.btnstart.TabIndex = 0;
            this.btnstart.Text = "Start";
            this.btnstart.UseVisualStyleBackColor = true;
            this.btnstart.Click += new System.EventHandler(this.btnstart_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(-2, 84);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(793, 373);
            this.tabControl2.TabIndex = 1;
            this.tabControl2.SelectedIndexChanged += new System.EventHandler(this.tabControl2_SelectedIndexChanged);
            this.tabControl2.TabIndexChanged += new System.EventHandler(this.tabControl2_TabIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Wheat;
            this.tabPage2.Controls.Add(this.chkdeviceweather);
            this.tabPage2.Controls.Add(this.chkdevicestorage);
            this.tabPage2.Controls.Add(this.chkdevicecurrentwifi);
            this.tabPage2.Controls.Add(this.chkdevicenameandos);
            this.tabPage2.Controls.Add(this.chkdevicebatterylevel);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(785, 347);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "Properties";
            // 
            // chkdeviceweather
            // 
            this.chkdeviceweather.AutoSize = true;
            this.chkdeviceweather.Location = new System.Drawing.Point(24, 195);
            this.chkdeviceweather.Name = "chkdeviceweather";
            this.chkdeviceweather.Size = new System.Drawing.Size(102, 17);
            this.chkdeviceweather.TabIndex = 4;
            this.chkdeviceweather.Text = "Weather Report";
            this.chkdeviceweather.UseVisualStyleBackColor = true;
            // 
            // chkdevicestorage
            // 
            this.chkdevicestorage.AutoSize = true;
            this.chkdevicestorage.Location = new System.Drawing.Point(24, 150);
            this.chkdevicestorage.Name = "chkdevicestorage";
            this.chkdevicestorage.Size = new System.Drawing.Size(140, 17);
            this.chkdevicestorage.TabIndex = 3;
            this.chkdevicestorage.Text = "Availble Device Storage";
            this.chkdevicestorage.UseVisualStyleBackColor = true;
            // 
            // chkdevicecurrentwifi
            // 
            this.chkdevicecurrentwifi.AutoSize = true;
            this.chkdevicecurrentwifi.Location = new System.Drawing.Point(24, 102);
            this.chkdevicecurrentwifi.Name = "chkdevicecurrentwifi";
            this.chkdevicecurrentwifi.Size = new System.Drawing.Size(136, 17);
            this.chkdevicecurrentwifi.TabIndex = 2;
            this.chkdevicecurrentwifi.Text = "Current Connected Wifi";
            this.chkdevicecurrentwifi.UseVisualStyleBackColor = true;
            // 
            // chkdevicenameandos
            // 
            this.chkdevicenameandos.AutoSize = true;
            this.chkdevicenameandos.Location = new System.Drawing.Point(24, 55);
            this.chkdevicenameandos.Name = "chkdevicenameandos";
            this.chkdevicenameandos.Size = new System.Drawing.Size(165, 17);
            this.chkdevicenameandos.TabIndex = 1;
            this.chkdevicenameandos.Text = "DeviceName and OS Version";
            this.chkdevicenameandos.UseVisualStyleBackColor = true;
            // 
            // chkdevicebatterylevel
            // 
            this.chkdevicebatterylevel.AutoSize = true;
            this.chkdevicebatterylevel.Location = new System.Drawing.Point(24, 19);
            this.chkdevicebatterylevel.Name = "chkdevicebatterylevel";
            this.chkdevicebatterylevel.Size = new System.Drawing.Size(122, 17);
            this.chkdevicebatterylevel.TabIndex = 0;
            this.chkdevicebatterylevel.Text = "Device BatteryLevel";
            this.chkdevicebatterylevel.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dvhistory);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(785, 347);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Historical Details";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dvhistory
            // 
            this.dvhistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvhistory.GridColor = System.Drawing.SystemColors.Control;
            this.dvhistory.Location = new System.Drawing.Point(3, 3);
            this.dvhistory.Name = "dvhistory";
            this.dvhistory.Size = new System.Drawing.Size(775, 344);
            this.dvhistory.TabIndex = 0;
            this.dvhistory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvhistory_CellContentClick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 462);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.statusStrip1.Size = new System.Drawing.Size(792, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(10, 17);
            this.toolStripStatusLabel1.Text = " ";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmHistoricalData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 484);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmHistoricalData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historical Data";
            this.Load += new System.EventHandler(this.frmHistoricalData_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvhistory)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnstart;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.CheckBox chkdeviceweather;
        private System.Windows.Forms.CheckBox chkdevicestorage;
        private System.Windows.Forms.CheckBox chkdevicecurrentwifi;
        private System.Windows.Forms.CheckBox chkdevicenameandos;
        private System.Windows.Forms.CheckBox chkdevicebatterylevel;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView dvhistory;
    }
}

