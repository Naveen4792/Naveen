﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Text;
using System.Windows.Forms;
using WlanCheck;

namespace HistoricalDataApp
{
    public partial class frmHistoricalData : Form
    {
        List<updateMainlist> lstupdateMainlist = new List<updateMainlist>();

        #region Events

        public frmHistoricalData()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmHistoricalData_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = DateTime.Now.ToString("MM/dd/yyyy");
            timer1.Enabled = false;
            //Startapplication();
        }

        private void btnstart_Click(object sender, EventArgs e)
        {
            try
            {
                int int1 = isvalidcheck();
                if (int1 >= 3)
                {
                    frmTime objfrmTime = new frmTime();
                    objfrmTime.ShowDialog();
                    if (objfrmTime.outvalue > 0)
                    {
                        this.timer1.Interval = objfrmTime.outvalue * 1000 * 60;
                        this.timer1.Enabled = true;
                        btnstart.Enabled = false;
                        btnClose.Enabled = false;
                        btnreset.Enabled = true;
                        btnStop.Enabled = true;
                        Startapplication();
                    }
                }
                else
                {
                    if (int1 == 0)
                        MessageBox.Show("Please select any of 3 options!");
                    else if (int1 < 3)
                        MessageBox.Show("Please select minimum of 3 options!");
                    chkdevicebatterylevel.Select();
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.timer1.Enabled = false;
            Startapplication();
            this.timer1.Enabled = true;
        }


        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                timer1.Enabled = false;
                btnstart.Enabled = true;
                btnClose.Enabled = true;
                btnreset.Enabled = true;
            }
            catch (Exception ex)
            {

            }
        }

        private void tabControl2_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dvhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnstart.Enabled = true;
            btnClose.Enabled = true;
            btnreset.Enabled = true;
            lstupdateMainlist = new List<updateMainlist>();
            dvhistory.DataSource = null;
            chkdevicebatterylevel.Checked = chkdeviceweather.Checked = chkdevicenameandos.Checked = chkdevicenameandos.Checked = chkdevicestorage.Checked = chkdevicecurrentwifi.Checked = false;
            chkdevicebatterylevel.Checked = chkdeviceweather.Checked = chkdevicenameandos.Checked = chkdevicenameandos.Checked = chkdevicestorage.Checked = chkdevicecurrentwifi.Checked = false;
            tabControl2.SelectedIndex = 0;
        }

        private void tabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dvhistory.DataSource == null && tabControl2.SelectedIndex == 1)
            {
                MessageBox.Show("No Historical details found", "Info!");
                tabControl2.SelectedIndex = 0;
            }
        }



        #endregion

        #region Methods

        private void Startapplication()
        {
            try
            {
                //chkdevicebatterylevel.Checked= chkdeviceweather.Checked = chkdevicenameandos.Checked = chkdevicenameandos.Checked = chkdevicestorage.Checked = chkdevicecurrentwifi.Checked = true;
                DataSet dsweather = new DataSet();
                object blevel = batterylevel();
                object devicename = deviceName();
                object osdetail = OSDetails();
                object driverdetails = DriveInfos();
                object wlandetails = Getconnectedwifi();


                if (chkdeviceweather.Checked)
                    dsweather = weatherreport();

                updateMainlist objupdateMainlist = new updateMainlist();
                if (lstupdateMainlist.Count == 0)
                    objupdateMainlist.Id = 1;
                else
                    objupdateMainlist.Id = lstupdateMainlist.Count + 1;
                objupdateMainlist.TriggerTime = Convert.ToString(DateTime.Now);// timer1.Interval / 60000;

                if (chkdevicebatterylevel.Checked)
                    objupdateMainlist.batterylevel = blevel.ToString();
                if (chkdevicenameandos.Checked)
                    objupdateMainlist.deviceName = devicename.ToString();
                if (chkdevicenameandos.Checked)
                    objupdateMainlist.OSDetails = osdetail.ToString();
                if (chkdevicestorage.Checked)
                    objupdateMainlist.DriveInfos = driverdetails.ToString();
                if (chkdevicecurrentwifi.Checked)
                    objupdateMainlist.ConnectedWifi = wlandetails.ToString();

                if (dsweather != null && chkdeviceweather.Checked)
                {
                    if (dsweather.Tables.Count >= 3)
                    {
                        for (int i = 0; i < dsweather.Tables.Count; i++)
                        {
                            if (dsweather.Tables[i].TableName.ToLower() == "temperature")
                            {
                                foreach (DataRow dr in dsweather.Tables[i].Rows)
                                {
                                    if (dr != null)
                                    {
                                        objupdateMainlist.weatherreport = "Min" + dr["min"].ToString() + ", : Max" + dr["max"].ToString();
                                        continue;
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(objupdateMainlist.weatherreport))
                                continue;
                        }
                    }
                }
                lstupdateMainlist.Add(objupdateMainlist);

                Setcolumnwidth();
            }
            catch (Exception ex)
            {

            }
        }

        private void Setcolumnwidth()
        {
            try
            {
                dvhistory.DataSource = null;
                dvhistory.DataSource = lstupdateMainlist;
                dvhistory.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dvhistory.Columns[3].Width = 160;
                dvhistory.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dvhistory.Columns[5].Width = 160;
            }
            catch (Exception ex)
            {
            }
        }
        private object batterylevel()
        {
            object batterylevel = string.Empty;
            try
            {
                ObjectQuery query = new ObjectQuery("Select * FROM Win32_Battery");
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
                ManagementObjectCollection collection = searcher.Get();

                foreach (ManagementObject mo in collection)
                {
                    foreach (PropertyData property in mo.Properties)
                    {
                        //MessageBox.Show("Property {0}: Value is {1}", property.Name + property.Value);

                        if (property.Name == "EstimatedChargeRemaining")
                        {

                            batterylevel = property.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                batterylevel = -1;
            }
            return batterylevel;
        }
        private object deviceName()
        {
            object deviceName = string.Empty;
            try
            {
                ObjectQuery query = new ObjectQuery("Select * FROM win32_computersystem");
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
                ManagementObjectCollection collection = searcher.Get();

                foreach (ManagementObject mo in collection)
                {
                    foreach (PropertyData property in mo.Properties)
                    {
                        //MessageBox.Show("Property {0}: Value is {1}", property.Name + property.Value);
                        if (property.Name == "Name")
                        {

                            deviceName = property.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                deviceName = -1;
            }
            return deviceName;
        }


        private object OSDetails()
        {
            object OSDetails = string.Empty;
            try
            {
                ObjectQuery query = new ObjectQuery("Select * FROM win32_operatingsystem");
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
                ManagementObjectCollection collection = searcher.Get();

                foreach (ManagementObject mo in collection)
                {
                    foreach (PropertyData property in mo.Properties)
                    {
                        // MessageBox.Show("Property {0}: Value is {1}", property.Name + property.Value);
                        if (property.Name == "Caption")
                        {

                            OSDetails = property.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                OSDetails = -1;
            }
            return OSDetails;
        }


        private object DriveInfos()
        {
            object OSDetails = string.Empty;
            try
            {
                DriveInfo[] drives = DriveInfo.GetDrives();
                foreach (DriveInfo drive in drives)
                {
                    if (drive.IsReady)
                    {
                        if (string.IsNullOrEmpty(Convert.ToString(OSDetails)))
                            OSDetails = drive.Name;// + " : " + drive.TotalSize;
                        else
                            OSDetails = OSDetails + "," + drive.Name;// + "  " + drive.TotalSize;
                    }
                }
            }
            catch (Exception ex)
            {
                OSDetails = -1;
            }
            return OSDetails;
        }



        private DataSet weatherreport()
        {
            var dataSet = new DataSet();
            try
            {
                string uri = string.Format("http://api.openweathermap.org/data/2.5/weather?q=Seoul&mode=xml&appid=78dff84492be32f8b4f77692904607a1", "India");

                using (var webClient = new WebClient())
                {
                    var response = webClient.DownloadData(uri);

                    var xml = Encoding.UTF8.GetString(response);

                    using (var sr = new StringReader(xml))
                    {
                        dataSet.ReadXml(sr);
                    }
                }

            }
            catch (Exception ex)
            {

            }
            return dataSet;
        }
        WlanClient wlan;
        private object Getconnectedwifi()
        {
            Collection<String> connectedSsids = new Collection<string>();
            object outconnection = "";
            try
            {
                wlan = new WlanClient();

                foreach (WlanClient.WlanInterface wlanInterface in wlan.Interfaces)
                {
                    Wlan.Dot11Ssid ssid = wlanInterface.CurrentConnection.wlanAssociationAttributes.dot11Ssid;
                    connectedSsids.Add(new String(Encoding.ASCII.GetChars(ssid.SSID, 0, (int)ssid.SSIDLength)));
                }
                outconnection = connectedSsids.FirstOrDefault();
            }
            catch (Exception ex)
            {


            }
            return outconnection;
        }

        private int isvalidcheck()
        {
            int countchecked = 0;
            try
            {
                if (chkdevicebatterylevel.Checked)
                    countchecked = countchecked + 1;
                if (chkdevicenameandos.Checked)
                    countchecked = countchecked + 1;
                if (chkdevicecurrentwifi.Checked)
                    countchecked = countchecked + 1;
                if (chkdevicestorage.Checked)
                    countchecked = countchecked + 1;
                if (chkdeviceweather.Checked)
                    countchecked = countchecked + 1;
            }
            catch (Exception)
            {

            }
            return countchecked;
        }

        #endregion
      
    }
}


public class updateMainlist
{
    public int Id { get; set; }

    public string TriggerTime { get; set; }
    public string batterylevel { get; set; }
    public string deviceName { get; set; }
    public string ConnectedWifi { get; set; }
    public string OSDetails { get; set; }
    public string DriveInfos { get; set; }
    public string weatherreport { get; set; }

}



